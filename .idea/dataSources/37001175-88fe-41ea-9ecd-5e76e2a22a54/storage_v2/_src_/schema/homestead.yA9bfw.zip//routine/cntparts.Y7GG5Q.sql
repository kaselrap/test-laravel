create function cntparts(var varchar(1024)) returns int
RETURN 1+LENGTH(var)-LENGTH(REPLACE(var,',',''));

