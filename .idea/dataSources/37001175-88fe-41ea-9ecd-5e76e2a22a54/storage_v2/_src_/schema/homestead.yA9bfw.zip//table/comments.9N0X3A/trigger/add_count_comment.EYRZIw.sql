create trigger add_count_comment
  after INSERT
  on comments
  for each row
BEGIN
                UPDATE articles SET count_comments = count_comments + 1
                WHERE id = NEW.article_id;
            END;

