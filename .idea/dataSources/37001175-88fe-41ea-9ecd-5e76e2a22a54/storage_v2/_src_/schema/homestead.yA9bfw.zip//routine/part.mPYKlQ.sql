create function part(x varchar(255), pos int) returns varchar(255)
BEGIN
  DECLARE delim char(1)
  ;SET delim=','
  ;RETURN TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(x, delim, pos),
                                 LENGTH(SUBSTRING_INDEX(x, delim, pos -1)) + 1),
                       delim, ''))
  ;END;

